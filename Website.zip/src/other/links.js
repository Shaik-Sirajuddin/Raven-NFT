export const discordLink = "https://discord.gg/s3AQXWjjYH"
export const twitterLink = "https://twitter.com/RavenGroupNFT"
